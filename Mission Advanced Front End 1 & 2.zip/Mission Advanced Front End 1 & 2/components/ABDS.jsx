import { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { getData, addData, updateData, deleteData } from '../services/api';
import { setCourses, addCourse, updateCourse, deleteCourse, setLoading, setError } from '../store/redux/coursesSlice';

import courseImage1 from '../components/assets/1.png';

const ABDS = () => {
    const dispatch = useDispatch();
    const courses = useSelector((state) => state.courses.data);
    const loading = useSelector((state) => state.courses.loading);
    const error = useSelector((state) => state.courses.error);

    const [activeCategory, setActiveCategory] = useState('Semua Kelas');
    const [formData, setFormData] = useState({ title: '', description: '', category: 'Pemasaran' });
    const categories = ['Semua Kelas', 'Pemasaran', 'Desain', 'Pengembangan Diri', 'Bisnis'];

    useEffect(() => {
        const fetchCourses = async () => {
            dispatch(setLoading(true));
            try {
                const data = await getData();
                dispatch(setCourses(data));
            } catch (err) {
                dispatch(setError(err.message));
            } finally {
                dispatch(setLoading(false));
            }
        };
        fetchCourses();
    }, [dispatch]);

    const handleDeleteCourse = async (id) => {
        if (window.confirm('Apakah Anda yakin ingin menghapus course ini?')) {
            try {
                await deleteData(id); 
                dispatch(deleteCourse(id)); 
                alert('Course berhasil dihapus');
            } catch (err) {
                alert('Gagal menghapus data: ' + err.message);
            }
        }
    };

    const startEditCourse = (course) => {
      
        const newTitle = prompt("Update Judul:", course.title);
        if (newTitle) {
            handleUpdateCourse(course.id, { ...course, title: newTitle });
        }
    };

    const handleUpdateCourse = async (id, updatedData) => {
        try {
            const data = await updateData(id, updatedData);
            dispatch(updateCourse(data));
        } catch (err) {
            alert('Gagal update data');
        }
    };
    const handleAddNewCourse = async () => {
        const newCourse = {
            title: "Course Baru",
            description: "Deskripsi course baru",
            category: "Pemasaran",
            imageUrl: courseImage1
        };

        try {
            const data = await addData(newCourse);
            dispatch(addCourse(data));
        } catch (err) {
            alert('Gagal menambah data');
        }
    };

    const filteredCourses = activeCategory === 'Semua Kelas' 
        ? courses 
        : courses.filter(course => course.category === activeCategory);

    return (
        <section className="featured-videos">
            <h2>Koleksi Video Pembelajaran Unggulan</h2>
            <div className="class-categories">
                {categories.map(category => (
                    <p 
                        key={category}
                        className={`category-link ${activeCategory === category ? 'active' : ''}`}
                        onClick={() => setActiveCategory(category)}
                        style={{ cursor: 'pointer' }}
                    >
                        {category}
                    </p>
                ))}
            </div>

            {loading && <p>Memuat data...</p>}
            {error && <p style={{ color: 'red' }}>Error: {error}</p>}

            <section className="course-grid">
                {!loading && filteredCourses.length === 0 && (
                    <div style={{ gridColumn: '1 / -1', textAlign: 'center', padding: '40px' }}>
                        <p>📭 Belum ada course.</p>
                    </div>
                )}
                
                {filteredCourses.map(course => (
                    <div className="course-card" key={course.id}>
                        <img 
                            src={course.imageUrl || 'https://via.placeholder.com/300x200'} 
                            alt={course.title}
                            style={{ width: '100%', height: '180px', objectFit: 'cover' }}
                        />
                        <div style={{ padding: '15px' }}>
                            <h4>{course.title}</h4>
                            <p>{course.description}</p>
                            <span className="badge">{course.category}</span>
                        </div>
                        
                        <div style={{ display: 'flex', gap: '5px', padding: '10px' }}>
                        </div>
                    </div>
                ))}
            </section>
        </section>
    );
}

export default ABDS;