import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './style/StyleNavbar.css'; 
import logoImage from '../components/assets/logo.png'; 
import profileImage from '../components/assets/pp.123.webp';
import Admin from '../pages/Admin';

const Navbar = () => {
    const [username, setUsername] = useState('Pengguna'); 
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const navigate = useNavigate();
    useEffect(() => {
        const storedUser = localStorage.getItem('currentUser');
        if (storedUser) {
            try {
                const user = JSON.parse(storedUser);
                const fullName = user.fullname || 'Pengguna';
                const firstName = fullName.split(' ')[0];
                setUsername(firstName);
            } catch (error) {
                setUsername('Pengguna');
            }
        }
    }, []);
    const handleProfileClick = () => {
        setIsMenuOpen(prev => !prev);
    };
    const handleLogout = () => {
        localStorage.removeItem('currentUser');
        setIsMenuOpen(false);
        alert("Anda telah berhasil Logout.");
        navigate('/masuk'); 
    };
    const handleAdmin = () =>{
        navigate('/Admin')
    }
    return (
        <header className="navbar">
            <img 
                src={logoImage}
                alt="Logo" 
                className="header-logo" 
                width="200px" 
                height="50px"
            />
            <nav>
                <p className="kategori">Kategori</p> 
                <div className="profile-wrapper" onClick={handleProfileClick}> 
                    <div className="profile-icon">
                        <img 
                            src={profileImage}
                            alt="Profile" 
                            aria-label="Profil Pengguna"
                        />
                    </div>
                    {isMenuOpen && (
                        <div className="dropdown-menu">
                            <p className="menu-username">Halo, {username}!</p>
                            <button onClick={handleAdmin} className="Admin-button">
                                My Course
                            </button>
                            <button onClick={handleLogout} className="logout-button">
                                Logout
                            </button>
                        </div>
                    )}
                </div>
            </nav>
        </header>
    );
}

export default Navbar;