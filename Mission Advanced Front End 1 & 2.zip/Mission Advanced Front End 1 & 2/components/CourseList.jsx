import { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { getData, addData, updateData, deleteData } from '../services/api';
import { setCourses, addCourse, updateCourse, deleteCourse, setLoading, setError } from '../store/redux/coursesSlice';
import { useEffect } from 'react';

import courseImage1 from '../components/assets/1.png';

const CourseList = () => {
    const dispatch = useDispatch();
    
    const courses = useSelector((state) => state.courses.data);
    const loading = useSelector((state) => state.courses.loading);
    const error = useSelector((state) => state.courses.error);

    const [showAddForm, setShowAddForm] = useState(false);
    const [showEditForm, setShowEditForm] = useState(false);
    const [editingCourse, setEditingCourse] = useState(null);
    const [formData, setFormData] = useState({
        title: '',
        description: '',
        category: 'Semua Kelas',
        imageUrl: ''
    });

    const [activeCategory, setActiveCategory] = useState('Semua Kelas');
    const categories = ['Semua Kelas', 'Pemasaran', 'Desain', 'Pengembangan Diri', 'Bisnis'];

    useEffect(() => {
        const fetchCourses = async () => {
            dispatch(setLoading(true));
            dispatch(setError(null));
            
            try {
                const data = await getData();
                dispatch(setCourses(data));
            } catch (err) {
                dispatch(setError(err.message || 'Gagal mengambil data courses'));
            } finally {
                dispatch(setLoading(false));
            }
        };

        fetchCourses();
    }, [dispatch]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };
    const handleAddCourse = async (e) => {
        e.preventDefault();
        dispatch(setLoading(true));
        
        try {
            const newCourse = await addData({
                ...formData,
                imageUrl: formData.imageUrl || 'https://via.placeholder.com/300x200?text=Course'
            });
            dispatch(addCourse(newCourse));
            setFormData({ title: '', description: '', category: 'Semua Kelas', imageUrl: '' });
            setShowAddForm(false);
            alert('✅ Course berhasil ditambahkan!');
        } catch (err) {
            alert('❌ Gagal menambahkan course: ' + err.message);
        } finally {
            dispatch(setLoading(false));
        }
    };
    const startEditCourse = (course) => {
        setEditingCourse(course);
        setFormData({
            title: course.title || '',
            description: course.description || '',
            category: course.category || 'Semua Kelas',
            imageUrl: course.imageUrl || ''
        });
        setShowEditForm(true);
        setShowAddForm(false);
    };
    const handleUpdateCourse = async (e) => {
        e.preventDefault();
        dispatch(setLoading(true));
        
        try {
            const updatedCourse = await updateData(editingCourse.id, formData);
            dispatch(updateCourse({ id: editingCourse.id, data: updatedCourse }));
            setFormData({ title: '', description: '', category: 'Semua Kelas', imageUrl: '' });
            setShowEditForm(false);
            setEditingCourse(null);
            alert('✅ Course berhasil diupdate!');
        } catch (err) {
            alert('❌ Gagal mengupdate course: ' + err.message);
        } finally {
            dispatch(setLoading(false));
        }
    };

    const handleDeleteCourse = async (id) => {
        if (!window.confirm('Apakah Anda yakin ingin menghapus course ini?')) {
            return;
        }
        
        dispatch(setLoading(true));
        
        try {
            await deleteData(id);
            dispatch(deleteCourse(id));
            alert('✅ Course berhasil dihapus!');
        } catch (err) {
            alert('❌ Gagal menghapus course: ' + err.message);
        } finally {
            dispatch(setLoading(false));
        }
    };

    const filteredCourses = activeCategory === 'Semua Kelas' 
        ? courses 
        : courses.filter(course => course.category === activeCategory);

    const cancelForm = () => {
        setShowAddForm(false);
        setShowEditForm(false);
        setEditingCourse(null);
        setFormData({ title: '', description: '', category: 'Semua Kelas', imageUrl: '' });
    };

    return (
        <>
            <div style={{ textAlign: 'center', margin: '20px 0' }}>
                <button 
                    onClick={() => { setShowAddForm(true); setShowEditForm(false); }}
                    style={{
                        padding: '10px 20px',
                        backgroundColor: '#4CAF50',
                        color: 'white',
                        border: 'none',
                        borderRadius: '5px',
                        cursor: 'pointer',
                        fontSize: '14px'
                    }}
                >
                    + Tambah Course Baru
                </button>
            </div>
            {(showAddForm || showEditForm) && (
                <div style={{
                    backgroundColor: '#f9f9f9',
                    padding: '20px',
                    margin: '20px auto',
                    maxWidth: '500px',
                    borderRadius: '10px',
                    boxShadow: '0 2px 10px rgba(0,0,0,0.1)'
                }}>
                    <h3>{showEditForm ? '✏️ Edit Course' : '➕ Tambah Course Baru'}</h3>
                    <form onSubmit={showEditForm ? handleUpdateCourse : handleAddCourse}>
                        <div style={{ marginBottom: '15px' }}>
                            <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                                Judul Course
                            </label>
                            <input
                                type="text"
                                name="title"
                                value={formData.title}
                                onChange={handleInputChange}
                                required
                                style={{
                                    width: '100%',
                                    padding: '10px',
                                    borderRadius: '5px',
                                    border: '1px solid #ddd',
                                    boxSizing: 'border-box'
                                }}
                            />
                        </div>
                        
                        <div style={{ marginBottom: '15px' }}>
                            <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                                Deskripsi
                            </label>
                            <textarea
                                name="description"
                                value={formData.description}
                                onChange={handleInputChange}
                                rows="3"
                                style={{
                                    width: '100%',
                                    padding: '10px',
                                    borderRadius: '5px',
                                    border: '1px solid #ddd',
                                    boxSizing: 'border-box'
                                }}
                            />
                        </div>
                        
                        <div style={{ marginBottom: '15px' }}>
                            <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                                Kategori
                            </label>
                            <select
                                name="category"
                                value={formData.category}
                                onChange={handleInputChange}
                                style={{
                                    width: '100%',
                                    padding: '10px',
                                    borderRadius: '5px',
                                    border: '1px solid #ddd'
                                }}
                            >
                                {categories.filter(c => c !== 'Semua Kelas').map(cat => (
                                    <option key={cat} value={cat}>{cat}</option>
                                ))}
                            </select>
                        </div>
                        
                        <div style={{ marginBottom: '15px' }}>
                            <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                                URL Gambar (opsional)
                            </label>
                            <input
                                type="url"
                                name="imageUrl"
                                value={formData.imageUrl}
                                onChange={handleInputChange}
                                placeholder="https://example.com/image.jpg"
                                style={{
                                    width: '100%',
                                    padding: '10px',
                                    borderRadius: '5px',
                                    border: '1px solid #ddd',
                                    boxSizing: 'border-box'
                                }}
                            />
                        </div>
                        
                        <div style={{ display: 'flex', gap: '10px' }}>
                            <button
                                type="submit"
                                disabled={loading}
                                style={{
                                    flex: 1,
                                    padding: '12px',
                                    backgroundColor: showEditForm ? '#2196F3' : '#4CAF50',
                                    color: 'white',
                                    border: 'none',
                                    borderRadius: '5px',
                                    cursor: loading ? 'not-allowed' : 'pointer',
                                    fontSize: '14px'
                                }}
                            >
                                {loading ? 'Processing...' : (showEditForm ? 'Update Course' : 'Simpan Course')}
                            </button>
                            <button
                                type="button"
                                onClick={cancelForm}
                                style={{
                                    flex: 1,
                                    padding: '12px',
                                    backgroundColor: '#f44336',
                                    color: 'white',
                                    border: 'none',
                                    borderRadius: '5px',
                                    cursor: 'pointer',
                                    fontSize: '14px'
                                }}
                            >
                                Batal
                            </button>
                        </div>
                    </form>
                </div>
            )}

            <section className="featured-videos">
                <h2>Pembelajaran Saya</h2>
                <div className="class-categories">
                    {categories.map(category => (
                        <p 
                            key={category}
                            className={`category-link ${activeCategory === category ? 'active' : ''}`}
                            onClick={() => setActiveCategory(category)}
                            style={{ cursor: 'pointer' }}
                        >
                            {category}
                        </p>
                    ))}
                </div>
            </section>

            {loading && (
                <div style={{ textAlign: 'center', padding: '20px', color: '#666' }}>
                    <p>⏳ Loading...</p>
                </div>
            )}
            {error && (
                <div style={{ textAlign: 'center', padding: '20px', color: 'red' }}>
                    <p>❌ Error: {error}</p>
                </div>
            )}

            <section className="course-grid">
                {!loading && filteredCourses.length === 0 && (
                    <div style={{ 
                        gridColumn: '1 / -1', 
                        textAlign: 'center', 
                        padding: '40px',
                        color: '#666'
                    }}>
                        <p>📭 Anda Mempunyai course. Klik "Tambah Course Baru" untuk menambahkan!</p>
                    </div>
                )}
                
                {filteredCourses.map(course => (
                    <div className="course-card" key={course.id} style={{ position: 'relative' }}>
                        <img 
                            src={course.imageUrl || 'https://via.placeholder.com/300x200?text=No+Image'}
                            alt={course.title || 'Course'} 
                            style={{ 
                                height: '180px', 
                                width: '100%', 
                                objectFit: 'cover',
                                borderRadius: '8px 8px 0 0'
                            }}
                            onError={(e) => {
                                e.target.src = 'https://via.placeholder.com/300x200?text=Image+Error';
                            }}
                        />
                        
                        <div style={{ padding: '15px' }}>
                            <h4 style={{ 
                                margin: '0 0 8px 0', 
                                fontSize: '16px',
                                color: '#333'
                            }}>
                                {course.title || 'Untitled Course'}
                            </h4>
                            <p style={{ 
                                margin: '0 0 8px 0', 
                                fontSize: '13px', 
                                color: '#666',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap'
                            }}>
                                {course.description || 'No description'}
                            </p>
                            <span style={{
                                display: 'inline-block',
                                padding: '3px 8px',
                                backgroundColor: '#e3f2fd',
                                color: '#1976d2',
                                borderRadius: '12px',
                                fontSize: '11px'
                            }}>
                                {course.category || 'Uncategorized'}
                            </span>
                        </div>
                        
                        <div style={{ 
                            display: 'flex', 
                            gap: '5px', 
                            padding: '10px 15px',
                            borderTop: '1px solid #eee'
                        }}>
                            <button
                                onClick={() => startEditCourse(course)}
                                style={{
                                    flex: 1,
                                    padding: '8px',
                                    backgroundColor: '#2196F3',
                                    color: 'white',
                                    border: 'none',
                                    borderRadius: '4px',
                                    cursor: 'pointer',
                                    fontSize: '12px'
                                }}
                            >
                                ✏️ Edit
                            </button>
                            <button
                                onClick={() => handleDeleteCourse(course.id)}
                                style={{
                                    flex: 1,
                                    padding: '8px',
                                    backgroundColor: '#f44336',
                                    color: 'white',
                                    border: 'none',
                                    borderRadius: '4px',
                                    cursor: 'pointer',
                                    fontSize: '12px'
                                }}
                            >
                                🗑️ Hapus
                            </button>
                        </div>
                    </div>
                ))}
            </section>
        </>
    );
}

export default CourseList;