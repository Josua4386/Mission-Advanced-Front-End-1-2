import './style/StyleFooter.css'; 
const Footer = () => {
    return (
        <footer>
            <div className="footer-main">
                <div className="footer-logo-col">
                    <div className="logo">videobelajar</div>
                    <p>Gali Potensi Anda Melalui Pembelajaran Video di hariesok.id!</p>
                    <p>Jl. Usman Effendi No. 50 Lowokwaru, Malang</p>
                    <p>+62-877-7123-1234</p>
                </div>
                <div className="footer-links-col">
                    <div>
                        <h5>Kategori</h5>
                        <p>Digital & Teknologi</p>
                        <p>Pemasaran</p>
                        <p>Manajemen Bisnis</p>
                        <p>Pengembangan Diri</p>
                        <p>Desain</p>
                    </div>
                    <div>
                        <h5>Perusahaan</h5>
                        <p>Tentang Kami</p>
                        <p>FAQ</p>
                        <p>Kebijakan Privasi</p>
                        <p>Ketentuan Layanan</p>
                        <p>Bantuan</p>
                    </div>
                    <div>
                        <h5>Komunitas</h5>
                        <p>Tips Sukses</p>
                        <p>Blog</p>
                    </div>
                </div>
            </div>
            <div className="footer-bottom">
                <p>&copy;2023 Gerobak Sayur All Rights Reserved.</p>
            </div>
        </footer>
    );
}

export default Footer;