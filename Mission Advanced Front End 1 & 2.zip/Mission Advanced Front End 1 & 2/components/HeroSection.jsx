const HeroSection = () => {
    return (
        <section className="hero-section">
            <div className="hero-content">
                <div className="hero-image-overlay">
                    <div className="hero-text-container">
                        <h1>Revolusi Pembelajaran: Temukan Ilmu Baru melalui Platform Video Interaktif!</h1>
                        <p>Temukan ilmu baru yang menarik dan mendalam melalui koleksi video pembelajaran berkualitas tinggi. Tidak hanya itu, Anda juga dapat berpartisipasi dalam latihan interaktif yang akan meningkatkan pemahaman Anda.</p>
                        <button className="cta-button">Temukan Video Course untuk Dipelajari</button>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default HeroSection;