import { createBrowserRouter, Navigate } from "react-router-dom";
import Beranda from "../pages/Beranda";
import Daftar from "../pages/Daftar";
import Masuk from "../pages/Masuk";
import Admin from "../pages/Admin";
export const router = createBrowserRouter([
    {
        path: "/",
        element: <Navigate to="/Beranda" replace />,
    },
    {
        path: "daftar/",
        element: <Daftar/>,
    },
    {
        path: "/Beranda",
        element: <Beranda/>,
    },
    {
        path: "/Masuk",
        element: <Masuk/>,
    },
    {
        path: "/Admin",
        element : <Admin/>,
    },
     {
        path: "*",
        element: <h1>404 - Halaman Tidak Ditemukan!</h1>,
    }
]);
