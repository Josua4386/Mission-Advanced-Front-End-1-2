import Footer from "../components/footer";
import Navbar from "../components/navbar2";
import ABDS from "../components/ABDS";
import HeroSection from "../components/HeroSection";
import Newsletter from "../components/Newsletter";
import '../components/style/StyleHome.css';
const Beranda = () => {

  return (
    <div>
      <Navbar />
      <HeroSection/>
      <ABDS/>
      <Newsletter/>
      <Footer/>
    </div>
  );
};

export default Beranda;