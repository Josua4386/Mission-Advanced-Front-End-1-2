import Navbar from "../components/navbar3";
import CourseList from "../components/CourseList";
const Admin = () => {

  return (
    <div>
    <Navbar />
    <CourseList/>
    </div>
  );
};

export default Admin;