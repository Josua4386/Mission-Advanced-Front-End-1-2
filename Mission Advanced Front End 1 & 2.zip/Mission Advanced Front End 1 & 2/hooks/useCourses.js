import { useState, useEffect, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getData, addData, updateData, deleteData } from '../services/api';
import { 
    setCourses, 
    addCourse, 
    updateCourse, 
    deleteCourse,
    setLoading,
    setError 
} from '../store/redux/coursesSlice';

/**
 * Custom hook untuk mengelola data courses dengan Redux dan API
 * @returns {Object} - courses, loading, error, dan fungsi CRUD
 */
const useCourses = () => {
    const dispatch = useDispatch();
    const courses = useSelector((state) => state.courses.data);
    const loading = useSelector((state) => state.courses.loading);
    const error = useSelector((state) => state.courses.error);
    const fetchCourses = useCallback(async () => {
        dispatch(setLoading(true));
        dispatch(setError(null));
        
        try {
            const data = await getData();
            dispatch(setCourses(data));
        } catch (err) {
            dispatch(setError(err.message || 'Gagal mengambil data courses'));
        } finally {
            dispatch(setLoading(false));
        }
    }, [dispatch]);

    /**
     * Tambah course baru
     * @param {Object} courseData - Data course baru
     */
    const handleAddCourse = useCallback(async (courseData) => {
        dispatch(setLoading(true));
        dispatch(setError(null));
        
        try {
            const newCourse = await addData(courseData);
            dispatch(addCourse(newCourse));
            return newCourse;
        } catch (err) {
            dispatch(setError(err.message || 'Gagal menambah course'));
            throw err;
        } finally {
            dispatch(setLoading(false));
        }
    }, [dispatch]);

    /**
     * Update course yang ada
     * @param {string|number} id - Course ID
     * @param {Object} courseData - Data yang diupdate
     */
    const handleUpdateCourse = useCallback(async (id, courseData) => {
        dispatch(setLoading(true));
        dispatch(setError(null));
        
        try {
            const updatedCourse = await updateData(id, courseData);
            dispatch(updateCourse({ id, data: updatedCourse }));
            return updatedCourse;
        } catch (err) {
            dispatch(setError(err.message || 'Gagal mengupdate course'));
            throw err;
        } finally {
            dispatch(setLoading(false));
        }
    }, [dispatch]);

    /**
     * Hapus course
     * @param {string|number} id - Course ID
     */
    const handleDeleteCourse = useCallback(async (id) => {
        dispatch(setLoading(true));
        dispatch(setError(null));
        
        try {
            await deleteData(id);
            dispatch(deleteCourse(id));
        } catch (err) {
            dispatch(setError(err.message || 'Gagal menghapus course'));
            throw err;
        } finally {
            dispatch(setLoading(false));
        }
    }, [dispatch]);

    useEffect(() => {
        fetchCourses();
    }, [fetchCourses]);

    return {
        courses,
        loading,
        error,
        fetchCourses,
        addCourse: handleAddCourse,
        updateCourse: handleUpdateCourse,
        deleteCourse: handleDeleteCourse,
    };
};

export default useCourses;
