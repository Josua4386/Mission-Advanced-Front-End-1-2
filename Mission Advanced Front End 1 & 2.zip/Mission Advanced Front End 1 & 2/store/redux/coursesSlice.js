
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    data: [],        
    loading: false, 
    error: null,    
};

const coursesSlice = createSlice({
    name: 'courses',
    initialState,
    reducers: {
        setCourses: (state, action) => {
            state.data = action.payload;
        },
        addCourse: (state, action) => {
            state.data.push(action.payload);
        },

        updateCourse: (state, action) => {
            const { id, data } = action.payload;
            const index = state.data.findIndex(course => course.id === id);
            if (index !== -1) {
                state.data[index] = { ...state.data[index], ...data };
            }
        },
        
        deleteCourse: (state, action) => {
            const id = action.payload;
            state.data = state.data.filter(course => course.id !== id);
        },

        setLoading: (state, action) => {
            state.loading = action.payload;
        },

        setError: (state, action) => {
            state.error = action.payload;
        },

        clearCourses: (state) => {
            state.data = [];
            state.error = null;
        },
    },
});

export const { 
    setCourses, 
    addCourse, 
    updateCourse, 
    deleteCourse,
    setLoading,
    setError,
    clearCourses
} = coursesSlice.actions;

export default coursesSlice.reducer;
