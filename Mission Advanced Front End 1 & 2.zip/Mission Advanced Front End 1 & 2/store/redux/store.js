import { configureStore } from '@reduxjs/toolkit';
import coursesReducer from './coursesSlice';

const store = configureStore({
    reducer: {

        courses: coursesReducer,
    },
    middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware({
            serializableCheck: false,
        }),

    devTools: import.meta.env.DEV,
});

export default store;
