/**
 * API Service Layer
 * Menggunakan Axios untuk HTTP requests dengan interceptor
 * 
 * Tugas 1: Implementasi Fake API dengan Axios
 */

import axios from 'axios';

// Mengambil base URL dari environment variable (.env)
const BASE_URL = import.meta.env.VITE_API_BASE_URL;

// Membuat Axios instance dengan konfigurasi default
const apiClient = axios.create({
    baseURL: BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
    timeout: 10000, // 10 detik timeout
});

// ==========================================
// INTERCEPTOR - Request
// Digunakan untuk menangani header, logging, dan otorisasi terpusat
// ==========================================
apiClient.interceptors.request.use(
    (config) => {
        // Logging request untuk debugging
        console.log(`[API Request] ${config.method?.toUpperCase()} ${config.url}`);
        
        // Contoh: Menambahkan Authorization header jika ada token
        // const token = localStorage.getItem('authToken');
        // if (token) {
        //     config.headers.Authorization = `Bearer ${token}`;
        // }
        
        return config;
    },
    (error) => {
        console.error('[API Request Error]', error);
        return Promise.reject(error);
    }
);

// ==========================================
// INTERCEPTOR - Response
// Digunakan untuk menangani response dan error secara terpusat
// ==========================================
apiClient.interceptors.response.use(
    (response) => {
        // Logging response sukses
        console.log(`[API Response] ${response.status} ${response.config.url}`);
        return response;
    },
    (error) => {
        // Error handling terpusat
        if (error.response) {
            // Server merespons dengan status error
            console.error(`[API Error] ${error.response.status}: ${error.response.data?.message || error.message}`);
        } else if (error.request) {
            // Request dibuat tapi tidak ada respons
            console.error('[API Error] No response received:', error.message);
        } else {
            // Error saat setting up request
            console.error('[API Error] Request setup failed:', error.message);
        }
        return Promise.reject(error);
    }
);

// ==========================================
// API FUNCTIONS - CRUD Operations
// ==========================================

/**
 * GET - Mengambil semua data courses
 * @returns {Promise} Array of courses
 */
export const getData = async () => {
    try {
        const response = await apiClient.get('/courses');
        return response.data;
    } catch (error) {
        throw error;
    }
};

/**
 * GET by ID - Mengambil satu course berdasarkan ID
 * @param {string|number} id - Course ID
 * @returns {Promise} Course object
 */
export const getDataById = async (id) => {
    try {
        const response = await apiClient.get(`/courses/${id}`);
        return response.data;
    } catch (error) {
        throw error;
    }
};

/**
 * POST - Menambahkan course baru
 * @param {Object} courseData - Data course baru
 * @returns {Promise} Created course object
 */
export const addData = async (courseData) => {
    try {
        const response = await apiClient.post('/courses', courseData);
        return response.data;
    } catch (error) {
        throw error;
    }
};

/**
 * PUT - Mengupdate course yang ada
 * @param {string|number} id - Course ID
 * @param {Object} courseData - Data course yang diupdate
 * @returns {Promise} Updated course object
 */
export const updateData = async (id, courseData) => {
    try {
        const response = await apiClient.put(`/courses/${id}`, courseData);
        return response.data;
    } catch (error) {
        throw error;
    }
};

/**
 * DELETE - Menghapus course
 * @param {string|number} id - Course ID
 * @returns {Promise} Deleted course object
 */
export const deleteData = async (id) => {
    try {
        const response = await apiClient.delete(`/courses/${id}`);
        return response.data;
    } catch (error) {
        throw error;
    }
};

// Export axios client untuk penggunaan custom jika diperlukan
export default apiClient;
